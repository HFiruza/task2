print('1st program')
print((9 ** 0.5) * 5)
print()

print('2nd program')
print(9.99 >= 9.98 and 1000 <= 1000.1)
print()

print('3rd program')
print(2*2+2)
print(2*(2+2))
print(2*2+2 == 2*(2+2))
print()

print('4th program')
print('123.456')
print(123.456 * 10)
print(int(1234.56 // 10))
print(1 - (2 + 3))
